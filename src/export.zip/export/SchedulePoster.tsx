import React from 'react';
import { PosterProps } from './types';
import { 
  getThemeColors,
  getTextColorForBg
} from './utils';
import { 
  buildTimeGrid, 
  toMin, 
  toHHMM, 
  generateMajorTicks, 
  generateSubTicks 
} from './timeGrid';

export default function SchedulePoster({ 
  data, 
  width = 2480, 
  height = 3508, 
  theme = "classic", 
  showLegend = false, 
  watermark 
}: PosterProps) {
  const colors = getThemeColors(theme);

  const days = data.days ?? ["Lunes","Martes","Miércoles","Jueves","Viernes"];
  const items = data.items ?? [];

  // Layout
  const margin = 64;
  const headerH = 140;
  const daysHeaderH = 72;
  const legendH = showLegend ? 96 : 0;

  const contentW = width - margin * 2;

  const leftColW = 220; // columna de horas
  const gridLeft = margin + leftColW;
  const gridW = contentW - leftColW;

  const colW = gridW / days.length;
  const borderColor = '#000';

  // Grilla temporal inteligente
  const grid = buildTimeGrid(
    items.map(i => ({ start: i.start, end: i.end })),
    { 
      minQuantum: data.tickStepMin ?? 5, 
      maxQuantum: 60, 
      cellCap: 200, 
      padTopMin: 5, 
      padBottomMin: 5 
    }
  );

  // extremos reales
  const minStart = Math.min(...items.map(i => toMin(i.start)));
  const maxEnd = Math.max(...items.map(i => toMin(i.end)));

  // anclar a horas cerradas
  const hourStart = Math.floor(minStart / 60) * 60;
  const hourEnd = Math.ceil(maxEnd / 60) * 60;
  const hourCount = Math.max(1, (hourEnd - hourStart) / 60);

  // ALTO POR HORA (compacto)
  const HOUR_PX = (h: number) => Math.max(110, Math.min(140, Math.round(h * 0.035)));
  const hourPx = HOUR_PX(height);           // ~120 px en A4
  const gridH = hourPx * hourCount;        // no más gigantismo
  
  // Layout (después de calcular gridH)
  const contentH = height - margin * 2;
  const gridTop = margin + headerH + daysHeaderH
                + Math.max(0, (contentH - headerH - daysHeaderH - gridH - legendH) / 2);

  // utilitario
  const pxPerMin = hourPx / 60;

  // Escala y posicionamiento (después de calcular gridTop)
  const total = grid.endMin - grid.startMin;
  const scale = gridH / total;
  const yOf = (hhmm: string) => gridTop + (toMin(hhmm) - grid.startMin) * scale;
  const yOfMin = (min: number) => gridTop + (min - grid.startMin) * scale;

  // Leyenda (materia→color)
  const legend = (() => {
    const map = new Map<string,string>();
    items.forEach((it) => { if (!map.has(it.title)) map.set(it.title, it.color || '#e5e7eb'); });
    return Array.from(map.entries());
  })();

  return (
    <svg 
      width={width} 
      height={height} 
      viewBox={`0 0 ${width} ${height}`}
      xmlns="http://www.w3.org/2000/svg"
    >
      {/* Fondo */}
      <rect width={width} height={height} fill={colors.background} />

      {/* Header */}
      <g transform={`translate(${margin}, ${margin})`}>
        {data.title && (
          <text x={0} y={0} fontFamily="Inter, system-ui, Arial" fontWeight="700" fontSize="72" fill="#0f172a" dominantBaseline="hanging">
            {data.title}
          </text>
        )}
        {data.subtitle && (
          <text x={0} y={84} fontFamily="Inter, system-ui, Arial" fontWeight="500" fontSize="32" fill="#475569" dominantBaseline="hanging">
            {data.subtitle}
          </text>
        )}
      </g>

      {/* Cabecera de días */}
      <g transform={`translate(${gridLeft}, ${margin + headerH})`}>
        <rect x={-leftColW} y={0} width={gridW + leftColW} height={daysHeaderH} fill={colors.headerBg} stroke={borderColor} strokeWidth="2" />
        {days.map((d, i) => (
          <g key={d} transform={`translate(${i * colW}, 0)`}>
            <rect x={0} y={0} width={colW} height={daysHeaderH} fill={colors.headerBg} stroke={borderColor} strokeWidth="2" />
            <text x={colW / 2} y={daysHeaderH / 2} fontFamily="Inter, system-ui, Arial" fontWeight="700" fontSize="26" textAnchor="middle" dominantBaseline="central" fill={colors.headerText}>{d}</text>
          </g>
        ))}
        <line x1={-2} y1={0} x2={-2} y2={daysHeaderH} stroke={borderColor} strokeWidth="2" />
      </g>

      {/* Columna izquierda de horas */}
      <g>
        {/* Borde externo de la columna */}
        <rect x={margin} y={gridTop} width={leftColW} height={gridH} fill="#fff" stroke={borderColor} strokeWidth="2" />
        
        {/* Filas de tiempo por hora */}
        {Array.from({ length: hourCount }, (_, k) => (
          <g key={`hour-${k}`}>
            <rect 
              x={margin} 
              y={gridTop + k * hourPx} 
              width={leftColW} 
              height={hourPx} 
              fill="#f3f4f6" 
              stroke={borderColor} 
              strokeWidth="1.5" 
            />
            <text 
              x={margin + leftColW/2} 
              y={gridTop + k * hourPx + hourPx/2}
              textAnchor="middle" 
              dominantBaseline="central"
              fontFamily="Inter, system-ui, Arial" 
              fontWeight="700" 
              fontSize="26" 
              fill="#0f172a"
            >
              {`${toHHMM(hourStart + k * 60)} – ${toHHMM(hourStart + (k + 1) * 60)}`}
            </text>
          </g>
        ))}
      </g>

      {/* Grilla vertical por días */}
      <g>
        {/* Borde externo */}
        <rect x={gridLeft} y={gridTop} width={gridW} height={gridH} fill="#fff" stroke={borderColor} strokeWidth="2" />
        
        {/* Verticales */}
        {days.map((_, i) => (
          <line key={`v-${i}`} x1={gridLeft + i * colW} y1={gridTop} x2={gridLeft + i * colW} y2={gridTop + gridH} stroke={borderColor} strokeWidth="1.5" />
        ))}
        <line x1={gridLeft + gridW} y1={gridTop} x2={gridLeft + gridW} y2={gridTop + gridH} stroke={borderColor} strokeWidth="2" />
        
        {/* Horizontales por hora */}
        {Array.from({ length: hourCount + 1 }, (_, k) => (
          <line key={`h-${k}`} x1={gridLeft} y1={gridTop + k * hourPx} x2={gridLeft + gridW} y2={gridTop + k * hourPx} stroke={borderColor} strokeWidth="1.5" />
        ))}
      </g>

      {/* Almuerzo */}
      {data.lunch && (() => {
        const s = toMin(data.lunch!.start);
        const e = s + Number(data.lunch!.durationMin || 0);
        if (e <= grid.startMin || s >= grid.endMin) return null;
        
        // Encontrar las horas que cubre el almuerzo
        const startHour = Math.floor((s - hourStart) / 60);
        const endHour = Math.ceil((e - hourStart) / 60);
        
        if (startHour < 0 || endHour > hourCount) return null;
        
        const y = gridTop + startHour * hourPx;
        const h = (endHour - startHour) * hourPx;
        
        return (
          <g>
            <rect x={gridLeft} y={y} width={gridW} height={h} fill="rgba(253,230,138,.35)" />
            <line x1={gridLeft} y1={y} x2={gridLeft + gridW} y2={y} stroke={borderColor} strokeWidth="2" />
            <line x1={gridLeft} y1={y + h} x2={gridLeft + gridW} y2={y + h} stroke={borderColor} strokeWidth="2" />
            <text x={gridLeft + gridW / 2} y={y + h / 2} textAnchor="middle" dominantBaseline="central" fontFamily="Inter, system-ui, Arial" fontWeight="700" fontSize="20" fill="#92400e">{data.lunch!.label || 'Almuerzo'}</text>
          </g>
        );
      })()}

      {/* Bloques */}
      <g>
        {items.map((it, idx) => {
          // suponiendo q = quantumMin (GCD) ya calculado
          const roundDownQ = (m: number) => Math.floor(m / grid.quantumMin) * grid.quantumMin;
          const roundUpQ = (m: number) => Math.ceil(m / grid.quantumMin) * grid.quantumMin;

          const sMin = roundDownQ(toMin(it.start));
          const eMin = roundUpQ(toMin(it.end));

          const y = gridTop + (sMin - hourStart) * pxPerMin;
          const h = Math.max(4, (eMin - sMin) * pxPerMin); // mínimo 4px
          const x = gridLeft + it.dayIndex * colW + 2;
          const w = colW - 4;

          const fg = it.textColor || getTextColorForBg(it.color);
          const inner = Math.max(12, Math.min(20, Math.floor(h * 0.1))); // padding interno
          const titleSize = Math.max(18, Math.min(30, Math.floor(h * 0.22)));
          const timeSize = Math.max(12, Math.min(20, Math.floor(h * 0.16)));
          const gap = Math.max(4, Math.floor(h * 0.06));
          const cx = x + w / 2;

          // Título recortado si es muy largo
          const title = it.title.length > 28 ? it.title.slice(0, 27) + "…" : it.title;

          return (
            <g key={idx}>
              <rect x={x} y={y} width={w} height={h} rx={8} ry={8} fill={it.color} stroke="#000" strokeWidth="1" />

              {/* Texto centrado en 2 líneas */}
              <text
                x={cx}
                y={y + h/2 - (titleSize + gap + timeSize)/2}
                textAnchor="middle"
                dominantBaseline="hanging"
                fontFamily="Inter, system-ui, Arial"
                fontWeight="700"
                fontSize={titleSize}
                fill={fg}
              >
                {title}
                <tspan
                  x={cx}
                  dy={gap + timeSize}
                  fontWeight="600"
                  fontSize={timeSize}
                >
                  {`${it.start} – ${it.end}`}
                </tspan>
              </text>
            </g>
          );
        })}
      </g>

      {/* Leyenda */}
      {showLegend && legend.length > 0 && (
        <g transform={`translate(${margin}, ${height - margin - legendH + 24})`}>
          {legend.map(([title, color], i) => (
            <g key={`lg-${i}`} transform={`translate(${i * 260}, 0)`}>
              <rect x={0} y={-14} width={24} height={24} rx={4} fill={color} stroke={borderColor} strokeWidth="1" />
              <text x={32} y={0} fontFamily="Inter, system-ui, Arial" fontSize="18" dominantBaseline="central">{title}</text>
            </g>
          ))}
        </g>
      )}

      {/* Watermark */}
      {watermark && (
        <text x={width - margin} y={height - margin} fontSize={16} textAnchor="end" fill="#94a3b8" fontFamily="Inter, system-ui, Arial">{watermark}</text>
      )}
    </svg>
  );
}
